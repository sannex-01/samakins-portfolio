<?php
session_start();
include 'php/config.php';

if (isset($_POST['login'])) { //email and password collection begin
  $email = $_POST['email'];
  $password = $_POST['password'];
  //email and password collection end

  //hash operation begin
  $password = md5($password);
  //hash operation end

  $query = "SELECT user_id FROM user WHERE email = '$email' AND password = '$password'";
  $result = mysqli_query($conn, $query);

  if (mysqli_num_rows($result) == 1) {
    $_SESSION['user'] = mysqli_fetch_array($result)[0];
    header('Location: index.php');
  } else {
    echo '<script> window.alert("Invalid Email or Password") </script>';
  }
}

mysqli_close($conn);
?>

<!DOCTYPE HTML>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sam Akins | Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <meta name="author" content="Samuel Akinyemi" />

  <!-- Place icon in the root directory -->
  <link rel="icon" href="../sannex logo.ico">

  <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700" rel="stylesheet">

  <!-- Animate.css -->
  <link rel="stylesheet" href="../assets/css/animate.css">
  <!-- Icomoon Icon Fonts-->
  <link rel="stylesheet" href="../assets/css/icomoon.css">
  <!-- Bootstrap  -->
  <link rel="stylesheet" href="../assets/css/bootstrap.css">
  <!-- Flaticons  -->
  <link rel="stylesheet" href="../assets/fonts/flaticon/font/flaticon.css">
  <!-- Owl Carousel -->
  <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
  <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
  <!-- Theme style  -->
  <link rel="stylesheet" href="../assets/css/style.css">

  <!-- Modernizr JS -->
  <script src="../assets/js/modernizr-2.6.2.min.js"></script>
  <!-- FOR IE9 below -->
  <!--[if lt IE 9]-->
  <script src="../assets/js/respond.min.js"></script>
  <!--[endif]-->

</head>

<body style="margin: auto; max-width: 700px;">
  <h1>SAMAKINS PORTFOLIO | Admin Login</h1>
  <div class="colorlib-page">
    <div class="colorlib-wrap">
      <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box">
        <div class="colorlib-narrow-content">
          <form action="#" method="post">
            <div class="form-group">
              <label for="email"> Email Address </label>
              <input name="email" type="mail" class="form-control">
            </div>
            <div class="form-group">
              <label for="password"> Password </label>
              <input name="password" type="password" class="form-control">
            </div>
            <div class="form-group">
              <input name="login" type="submit" class="btn btn-primary" value="Sign In">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>



  <!-- jQuery -->
  <script src="../assets/js/jquery.min.js"></script>
  <!-- jQuery Easing -->
  <script src="../assets/js/jquery.easing.1.3.js"></script>
  <!-- Bootstrap -->
  <script src="../assets/js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="../assets/js/jquery.waypoints.min.js"></script>
  <!-- Owl carousel -->
  <script src="../assets/js/owl.carousel.min.js"></script>
  <!-- Counters -->
  <script src="../assets/js/jquery.countTo.js"></script>


  <!-- MAIN JS -->
  <script src="../assets/js/main.js"></script>

</body>

</html>