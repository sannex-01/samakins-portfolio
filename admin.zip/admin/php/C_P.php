<?php
session_start();
include 'config.php';

if (isset($_POST['C_P'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone_no = $_POST['phone_no'];
  $address = $_POST['address'];
  $C_P = $_POST['C_P'];

  $query = mysqli_query($conn, "SELECT * FROM `$C_P` WHERE `email` = '$email'");
  $row = mysqli_num_rows($query);
  $fetch = mysqli_fetch_array($query);

  if ($row == 0) {
    if ($_POST['portfolio_link'] == NULL) {
      $query1 = "INSERT INTO `$C_P` (name, email, phone_no, address) 
              VALUES ('$name', '$email', '$phone_no', '$address')";
    } else {
      $portfolio_link = $_POST['portfolio_link'];

      $query1 = "INSERT INTO `$C_P` (name, email, portfolio_link, phone_no, address) 
              VALUES ('$name', '$email', '$portfolio_link', '$phone_no', '$address')";
    }

    if (mysqli_query($conn, $query1) === TRUE) {
      header('Location: ../index.php#C_P');
    } else {
      echo '<script> window.alert('.mysqli_error($conn).') </script>';
    }
  } else {
    echo '<script> window.alert("'.$C_P.' already exist with this name - '.$fetch['name'].'! \n\nClick the back arrow to post new Organisation.") </script>';
  }
} else {
  echo '<script> window.alert("error 420") </script>';
}

mysqli_close($conn);
?>