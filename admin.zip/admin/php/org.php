<?php
session_start();
include 'config.php';

if (isset($_POST['submit_org'])) {
  $org_name = $_POST['org_name'];
  $org_city = $_POST['org_city'];
  $org_state = $_POST['org_state'];
  $org_country = $_POST['org_country'];
  $user_id = $_POST['user'];

  $query = mysqli_query($conn, "SELECT * FROM `organisation` WHERE `org_name` = '$org_name'");
  $row = mysqli_num_rows($query);

  if ($row == 0) {
    $query1 = "INSERT INTO organisation (user_id, org_name, org_city, org_state, org_country) 
              VALUES ($user_id, '$org_name', '$org_city', '$org_state', '$org_country')";

    if (mysqli_query($conn, $query1) === TRUE) {
      echo '<script> window.alert("Successfully Posted") </script>';

      header('Location: ../index.php');
    } else {
      echo '<script> window.alert('.mysqli_error($conn).') </script>';
    }
  } else {
    echo '<script> window.alert("Organisation Already exist! \n\nClick the back arrow to post new Organisation.") </script>';
  }
}

mysqli_close($conn);
?>
