<?php
	$conn = mysqli_connect("localhost", "root", "", "sam_portfolio");
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}

?>