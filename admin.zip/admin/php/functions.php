<?php
require_once('config.php');

function organisation($conn)
{
  $query1 = mysqli_query($conn, "SELECT * FROM organisation ORDER BY org_name") or die($conn);
  $row = mysqli_num_rows($query1);

  for ($org_id = 1; $org_id <= $row; $org_id++) {
    $sql = "SELECT * FROM organisation WHERE org_id = '$org_id'";
    $query2 = mysqli_query($conn, $sql);
    $fetch = mysqli_fetch_array($query2);
    echo "<input type='radio' name='org_id' value='" . $fetch['org_id'] . "'> " . $fetch['org_name'] . "<br>";
  }
}

function C_P($conn, $name)
{
  $query1 = mysqli_query($conn, "SELECT * FROM `$name` ORDER BY `name`") or die($conn);
  $row = mysqli_num_rows($query1);

  for ($id = 1; $id <= $row; $id++) {
    $sql = "SELECT * FROM `$name` WHERE `id` = '$id'";
    $query2 = mysqli_query($conn, $sql);
    $fetch = mysqli_fetch_array($query2);
    echo "<input type='radio' name='".$name."_id' value='" . $fetch['id'] . "'> " . $fetch['name'] . "<br>";
  }
}

?>
