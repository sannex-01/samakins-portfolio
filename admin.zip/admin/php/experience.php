<?php
session_start();
include 'config.php';

if (isset($_POST['submit_exp'])) {
  $user_id = $_POST['user'];
  $icon = $_POST['icon'];
  $title = $_POST['title'];
  $content = $_POST['content'];
  $org_id = $_POST['org_id'];
  $start_date = $_POST['start_date'];
  $end_date = $_POST['end_date'];
  $skills = $_POST['skills'];

  $query = mysqli_query($conn, "SELECT * FROM `experience` WHERE `title` = '$title'");
  $row = mysqli_num_rows($query);

  if ($row == 0) {
    $query1 = "INSERT INTO experience (user_id, icon, title, content, org_id, start_date, end_date, skills) 
              VALUES ($user_id, '$icon', '$title', '$content', '$org_id', '$start_date', '$end_date', '$skills')";

    if (mysqli_query($conn, $query1) === TRUE) {
      header('Location: ../index.php#experience');
      echo '<script> window.alert("Successfully Posted") </script>';
    } else {
      echo '<script> window.alert('.mysqli_error($conn).') </script>';
    }
  } else {
    echo '<script> window.alert("Experience Already exist! \n\nClick the back arrow to post new Organisation.") </script>';
  }
}

mysqli_close($conn);
?>