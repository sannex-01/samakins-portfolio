<?php
session_start();
include 'config.php';

if (isset($_POST['submit_cert'])) {
  $logo = $_FILES["logo"]["name"];
  $tempname = $_FILES["logo"]["tmp_name"];
  $logo_folder = "logo/" . $logo;

  $certificate = $_FILES["certificate"]["name"];
  $tempname2 = $_FILES["certificate"]["tmp_name"];
  $cert_folder = "certificates/" . $certificate;

  $title = $_POST['title'];
  $content = $_POST['content'];
  $user_id = $_POST['user'];
  $logo = "admin/php/logo/".$logo;
  $link = "admin/php/certificates/".$certificate;

  if (move_uploaded_file($tempname, $logo_folder) && move_uploaded_file($tempname2, $cert_folder)) {
    $query = "INSERT INTO `certificate` (`user_id`, `logo`, `title`, `content`, `link`) VALUES ($user_id, '$logo', '$title', '$content', '$link')";
    if (mysqli_query($conn, $query) === TRUE) {;
      echo '<script> window.alert("Successfully Posted") </script>';
      header('Location: ../index.php#certificates');
    } else {
      echo '<script> window.alert("'.mysqli_error($conn).' user = '.$user_id.'") </script>';
    }
  } else {
    echo '<script> window.alert("Unable to Save File in Directory") </script>';
  }

}

?>