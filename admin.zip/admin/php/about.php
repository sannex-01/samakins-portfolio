<?php
session_start();
include 'config.php';

if (isset($_POST['submit_about'])) {
  $paragraph1 = $_POST['paragraph1'];
  $paragraph2 = $_POST['paragraph2'];
  $user_id = $_POST['user'];
  $date = $_POST['date'];

  $query = "INSERT INTO about (user, paragraph1, paragraph2, date_posted) VALUES ($user_id, '$paragraph1', '$paragraph2', '$date')";
  if (mysqli_query($conn, $query) === TRUE) {
    echo '<script> window.alert("Successfully Posted") </script>';

    header('Location: ../index.php');
  } else {
    echo '<script> window.alert("<strong>Error Message:</strong> <br>+' . mysqli_error($conn) . '") </script>';
  }
}

mysqli_close($conn);
?>