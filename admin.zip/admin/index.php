<?php
session_start();
include 'php/functions.php';

if (!isset($_SESSION['user'])) {
  header('Location: login.php');
}

?>

<!DOCTYPE HTML>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sam Akins | Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="" />
  <meta name="keywords" content="" />
  <meta name="author" content="Samuel Akinyemi" />

  <!-- Facebook and Twitter integration -->
  <meta property="og:title" content="" />
  <meta property="og:image" content="" />
  <meta property="og:url" content="" />
  <meta property="og:site_name" content="" />
  <meta property="og:description" content="" />
  <meta name="twitter:title" content="" />
  <meta name="twitter:image" content="" />
  <meta name="twitter:url" content="" />
  <meta name="twitter:card" content="" />

  <!-- Place icon in the root directory -->
  <link rel="icon" href="../sannex logo.ico">

  <link href="https://fonts.googleapis.com/css?family=Quicksand:300,400,500,700" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Playfair+Display:400,400i,700" rel="stylesheet">

  <!-- Animate.css -->
  <link rel="stylesheet" href="../assets/css/animate.css">
  <!-- Icomoon Icon Fonts-->
  <link rel="stylesheet" href="../assets/css/icomoon.css">
  <!-- Bootstrap  -->
  <link rel="stylesheet" href="../assets/css/bootstrap.css">
  <!-- Flaticons  -->
  <link rel="stylesheet" href="../assets/fonts/flaticon/font/flaticon.css">
  <!-- Owl Carousel -->
  <link rel="stylesheet" href="../assets/css/owl.carousel.min.css">
  <link rel="stylesheet" href="../assets/css/owl.theme.default.min.css">
  <!-- Theme style  -->
  <link rel="stylesheet" href="../assets/css/style.css">

  <!-- Modernizr JS -->
  <script src="../assets/js/modernizr-2.6.2.min.js"></script>
  <!-- FOR IE9 below -->
  <!--[if lt IE 9]-->
  <script src="../assets/js/respond.min.js"></script>
  <!--[endif]-->

</head>

<body>
  <div id="colorlib-page">
    <div class="container-wrap">
      <a href="#" class="js-colorlib-nav-toggle colorlib-nav-toggle" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"><i></i></a>
      <aside id="colorlib-aside" role="complementary" class="border js-fullheight">
        <div class="text-center">
          <div class="author-img" style="background-image: url(../docs/images/about.jpg);"></div>
          <h1 id="colorlib-logo"><a href="../index.html">Samuel Akinyemi</a></h1>
          <span class="position"><a href="#">Web Developer</a> in Nigeria</span>
        </div>
        <nav id="colorlib-main-menu" role="navigation" class="navbar">
          <div id="navbar" class="collapse">
            <ul>
              <li class="active"><a href="#" data-nav-section="home">Home</a></li>
              <li><a href="#" data-nav-section="about">About</a></li>
              <li><a href="#" data-nav-section="organisation">Organisation</a></li>
              <li><a href="#" data-nav-section="experience">Experience</a></li>
              <li><a href="#" data-nav-section="certificates">Certificates</a></li>
              <li><a href="#" data-nav-section="skills">Skills</a></li>
              <li><a href="#" data-nav-section="education">Education</a></li>
              <li><a href="#" data-nav-section="awards">Honors & Awards</a></li>
              <li><a href="#" data-nav-section="work">Work</a></li>
              <li><a href="#" data-nav-section="blog">Blog</a></li>
              <li><a href="#" data-nav-section="contact">Contact</a></li>
            </ul>
          </div>
        </nav>

        <div class="colorlib-footer">
          <p><small>&copy;
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              Copyright
              <script>
                document.write(new Date().getFullYear());
              </script> All rights reserved. Made with <i class="icon-heart" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. --> </span>
              <span>Distributed by <a href="https://themewagon.com" target="_blank">ThemeWagon</a></span> <span>Demo
                Images: <a href="https://unsplash.com/" target="_blank">Unsplash.com</a></span>
            </small></p>
          <ul>
            <li><a href="https://facebook.com/sannexceo"><i class="icon-facebook2"></i></a></li>
            <li><a href="https://twitter.com/sam-akins"><i class="icon-twitter2"></i></a></li>
            <li><a href="https://instagram.com/"><i class="icon-instagram"></i></a></li>
            <li><a href="https://linkedin.com/in/akinyemi-samuel-927751225"><i class="icon-linkedin2"></i></a></li>
          </ul>
        </div>

      </aside>

      <div id="colorlib-main">
        <section class="colorlib-about" data-section="home">
          <div class="colorlib-narrow-content">
            <div class="row">
              <div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
                <div class="hire">
                  <h2>I am happy to know you <br>that 100+ projects done sucessfully!</h2>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="colorlib-contact" data-section="about">
          <div class="colorlib-narrow-content">
            <div class="row">
              <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <span class="heading-meta">Update on About</span>
                <h2 class="colorlib-heading">Who am I?</h2>
              </div>
            </div>
            <div class="row">
              <div class="row">
                <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInRight">
                  <form action="assets/php/about.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['user'] ?>">
                    <input type="hidden" name="date" id="date" value="">
                    <div class="form-group">
                      <textarea name="paragraph1" cols="30" rows="7" class="form-control" placeholder="Paragraph1" required></textarea>
                    </div>
                    <div class="form-group">
                      <textarea name="paragraph2" cols="30" rows="7" class="form-control" placeholder="Paragraph2"></textarea>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit_about" class="btn btn-primary btn-send-message" value="Post">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="colorlib-contact" data-section="organisation">
          <div class="colorlib-narrow-content">
            <div class="row">
              <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <span class="heading-meta">Update on Organisation</span>
                <h2 class="colorlib-heading">Add New Organisation</h2>
              </div>
            </div>
            <div class="row">
              <div class="row">
                <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInRight">
                  <form action="php/org.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['user'] ?>">
                    <div class="form-group">
                      <input type="text" name="org_name" class="form-control" placeholder="Organisation Name" required>
                    </div>
                    <div class="form-group">
                      <input type="text" name="org_city" class="form-control" placeholder="Organisation City" required>
                    </div>
                    <div class="form-group">
                      <input type="text" name="org_state" class="form-control" placeholder="Organisation State" required>
                    </div>
                    <div class="form-group">
                      <input type="text" name="org_country" class="form-control" placeholder="Organisation Country" required>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit_org" class="btn btn-primary btn-send-message" value="Update">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="experience" class="colorlib-contact" data-section="experience">
          <div class="colorlib-narrow-content">
            <div class="row">
              <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <span class="heading-meta">Update on Experience</span>
                <h2 class="colorlib-heading">Add New Experience</h2>
              </div>
            </div>
            <div class="row">
              <div class="row">
                <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInRight">
                  <form action="php/experience.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['user'] ?>">
                    <div class="form-group">
                      <input type="text" name="icon" class="form-control" placeholder="Icomoon Icon Link">
                    </div>
                    <div class="form-group">
                      <input type="text" name="title" class="form-control" placeholder="Title">
                    </div>
                    <div class="form-group">
                      <textarea name="content" cols="30" rows="7" class="form-control" placeholder="Description"></textarea>
                    </div>
                    <div class="form-group">
                      <strong>ORGANISATION</strong> <br>
                      <?php organisation($conn); ?>
                    </div>
                    <div class="form-group">
                      <input type="text" name="start_date" class="form-control" placeholder="Start Date (format -- Dec 2022)...">
                    </div>
                    <div class="form-group">
                      <input type="text" name="end_date" class="form-control" placeholder="End Date (format -- April 2022)...">
                    </div>
                    <div class="form-group">
                      <textarea name="skills" cols="30" rows="7" class="form-control" placeholder="Skills: e.g Time management, etc."></textarea>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit_exp" class="btn btn-primary btn-send-message" value="Update">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="certificates" class="colorlib-contact" data-section="certificates">
          <div class="colorlib-narrow-content">
            <div class="row">
              <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <span class="heading-meta">Update on certification</span>
                <h2 class="colorlib-heading">Add New Certificate</h2>
              </div>
            </div>
            <div class="row">
              <div class="row">
                <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInRight">
                  <form enctype="multipart/form-data" action="php/certificate.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['user'] ?>">
                    <div class="form-group">
                      <label for="logo"> Company's Logo </label>
                      <input type="file" name="logo" class="form-control" required>
                    </div>
                    <div class="form-group">
                      <input type="text" name="title" class="form-control" placeholder="Title" required>
                    </div>
                    <div class="form-group">
                      <textarea name="content" cols="30" rows="7" class="form-control" placeholder="Description" required></textarea>
                    </div>
                    <div class="form-group">
                      <label for="logo"> Certificate File (either .png or .jpg or .pdf) </label>
                      <input type="file" name="certificate" class="form-control" required>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="submit_cert" class="btn btn-primary btn-send-message" value="Update">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="C_P" class="colorlib-contact" data-section="C_P">
          <div class="colorlib-narrow-content">
            <div class="row">
              <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <span class="heading-meta">Update on Partners and Clients</span>
                <h2 class="colorlib-heading">Add New Client or Partner</h2>
              </div>
            </div>
            <div class="row">
              <div class="row">
                <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInRight">
                  <form action="php/C_P.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['user'] ?>">
                    <div class="form-group">
                      <input type="text" name="name" class="form-control" placeholder="Client's Name" required>
                    </div>
                    <div class="form-group">
                      <input type="mail" name="email" class="form-control" placeholder="Client's Email" required>
                    </div>
                    <div class="form-group">
                      <input type="tel" name="phone_no" class="form-control" placeholder="Client's Phone Number" required>
                    </div>
                    <div class="form-group">
                      <input type="text" name="address" class="form-control" placeholder="Client's Address" required>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="C_P" class="btn btn-primary btn-send-message" value="client">
                    </div>
                  </form>
                  <form action="php/C_P.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['user'] ?>">
                    <div class="form-group">
                      <input type="text" name="name" class="form-control" placeholder="Partner's Name" required>
                    </div>
                    <div class="form-group">
                      <input type="mail" name="email" class="form-control" placeholder="Partner's Email" required>
                    </div>
                    <div class="form-group">
                      <input type="text" name="portfolio_link" class="form-control" placeholder="Partner's Portfolio Link" required>
                    </div>
                    <div class="form-group">
                      <input type="tel" name="phone_no" class="form-control" placeholder="Partner's Phone Number" required>
                    </div>
                    <div class="form-group">
                      <input type="text" name="address" class="form-control" placeholder="Partner's Address" required>
                    </div>
                    <div class="form-group">
                      <input type="submit" name="C_P" class="btn btn-primary btn-send-message" value="partner">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="colorlib-contact" data-section="about">
          <div class="colorlib-narrow-content">
            <div class="row">
              <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <span class="heading-meta">Update on latest work</span>
                <h2 class="colorlib-heading">Add New Work</h2>
              </div>
            </div>
            <div class="row">
              <div class="row">
                <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInRight">
                  <form action="assets/php/experience.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['user'] ?>">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="paragraph1">
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="paragraph2">
                    </div>
                    <div class="form-group">
                      <strong>Select Client</strong> <br>
                      <?php C_P($conn, 'client'); ?>
                    </div>
                    <div class="form-group">
                      <strong>Select Partner</strong> <br>
                      <?php C_P($conn, 'partner'); ?>
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Subject">
                    </div>
                    <div class="form-group">
                      <textarea name="" id="message" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
                    </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary btn-send-message" value="Send Message">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section class="colorlib-contact" data-section="about">
          <div class="colorlib-narrow-content">
            <div class="row">
              <div class="col-md-6 col-md-offset-3 col-md-pull-3 animate-box" data-animate-effect="fadeInLeft">
                <span class="heading-meta">Update on Experience</span>
                <h2 class="colorlib-heading">Add New Experience</h2>
              </div>
            </div>
            <div class="row">
              <div class="row">
                <div class="col-md-10 col-md-offset-1 col-md-pull-1 animate-box" data-animate-effect="fadeInRight">
                  <form action="assets/php/experience.php" method="post">
                    <input type="hidden" name="user" value="<?php echo $_SESSION['user'] ?>">
                    <input type="hidden" name="date" id="date" value="">
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="paragraph1">
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="paragraph2">
                    </div>
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Subject">
                    </div>
                    <div class="form-group">
                      <textarea name="" id="message" cols="30" rows="7" class="form-control" placeholder="Message"></textarea>
                    </div>
                    <div class="form-group">
                      <input type="submit" class="btn btn-primary btn-send-message" value="Send Message">
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>

      </div><!-- end:colorlib-main -->
    </div><!-- end:container-wrap -->
  </div><!-- end:colorlib-page -->

  <!-- jQuery -->
  <script src="../assets/js/jquery.min.js"></script>
  <!-- jQuery Easing -->
  <script src="../assets/js/jquery.easing.1.3.js"></script>
  <!-- Bootstrap -->
  <script src="../assets/js/bootstrap.min.js"></script>
  <!-- Waypoints -->
  <script src="../assets/js/jquery.waypoints.min.js"></script>
  <!-- Owl carousel -->
  <script src="../assets/js/owl.carousel.min.js"></script>
  <!-- Counters -->
  <script src="../assets/js/jquery.countTo.js"></script>


  <!-- MAIN JS -->
  <script src="../assets/js/main.js"></script>

  <script>
    var d = new Date();
    var months = ["Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"];
    document.getElementById("date").value = months[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear();
  </script>

</body>

</html>