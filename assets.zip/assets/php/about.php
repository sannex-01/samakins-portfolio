<?php

require_once 'config.php';

  $query = mysqli_query($conn, "SELECT * FROM `about` ORDER BY `id` DESC LIMIT 1") or die($conn);
  $fetch = mysqli_fetch_array($query);
  $row = mysqli_num_rows($query);

  $paragraph1 = $fetch['paragraph1'];
  $paragraph2 = $fetch['paragraph2'];

  mysqli_close($conn);
?>