<?php
function experience()
{
  $conn = mysqli_connect("localhost", "root", "", "sam_portfolio");

  $result = mysqli_query($conn, "SELECT * FROM `experience` ORDER BY `date_added` DESC") or die($conn);
  $row1 = mysqli_num_rows($result);

  for ($exp_id = $row1; $exp_id >= 1; $exp_id--) {
    $query = mysqli_query($conn, "SELECT * FROM experience WHERE id = '$exp_id' ORDER BY `id` DESC");
    $fetch = mysqli_fetch_array($query);

    echo ('<article class="timeline-entry animate-box" data-animate-effect="fadeInRight">
				<div class="timeline-entry-inner">
					<div class="timeline-icon color-'.$exp_id.'">
						<i class="' . $fetch['icon'] . '"></i>
					</div>  
					<div class="timeline-label">
						<h2><a href="#">' . $fetch['title'] . '</a> <span>' . $fetch['start_date'] . ' - ' . $fetch['end_date'] . '</span></h2>
						<p>' . $fetch['content'] . '
		        	<br><strong>Skills Acquired: <i>' . $fetch['skills'] . '</i></strong>.
						</p>
					</div>
				</div>
      </article>'
    );
  }
}

?>