<?php
function certificate()
{
  $conn = mysqli_connect("localhost", "root", "", "sam_portfolio");

  $result = mysqli_query($conn, "SELECT * FROM `certificate` ORDER BY `id` DESC LIMIT 6") or die($conn);

  while ($row = mysqli_fetch_array($result)) {
    echo ('
          <div class="col-md-4 text-center animate-box">
            <div class="certificates color-'.$row['id'].'">
              <span class="icon" style="background-image: url('.$row['logo'].');background-size: cover;background-position: center;">

              </span>
              <div class="desc">
                <h3>' . $row['title'] .'</h3>
                <p>' . $row['content'] .'
                  <br> Click <a href="' . $row['link'] . '">here </a>to get a copy
                </p>
              </div>
            </div>
          </div>'
    );
  }
}
?>