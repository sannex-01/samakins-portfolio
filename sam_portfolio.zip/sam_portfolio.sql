-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2023 at 12:28 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sam_portfolio`
--
CREATE DATABASE IF NOT EXISTS `sam_portfolio` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `sam_portfolio`;

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `paragraph1` text NOT NULL,
  `paragraph2` text NOT NULL,
  `date_posted` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `user`, `paragraph1`, `paragraph2`, `date_posted`) VALUES
(1, 1, 'I am the first born of the Yinka-Akinyemi Family. (I) am geared towards motivating and inspiring mine and the upcoming generation with my love for Fashion and passion for.', 'My foundation is built on the trust of God and my time and intelligence is invested into Computer Science, deeply grounded in web programming and currently laying my foundation for the study of Data.', 'Dec 17, 2022'),
(2, 1, 'I am the first born of the Yinka-Akinyemi Family. I am geared towards motivating and inspiring mine and the upcoming generation with my love for Fashion and passion for Technology.', 'My foundation is built on the trust of God and my time and intelligence is invested into Computer Science, deeply grounded in web programming and currently laying my foundation for the study of Data.', 'Dec 17, 2022');

-- --------------------------------------------------------

--
-- Table structure for table `award`
--

CREATE TABLE `award` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `org_id` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  `title` text NOT NULL,
  `content` text NOT NULL,
  `category` text NOT NULL,
  `picture` varchar(25) NOT NULL,
  `views` int(100) NOT NULL,
  `likes` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `certificate`
--

CREATE TABLE `certificate` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `link` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `certificate`
--

INSERT INTO `certificate` (`id`, `user_id`, `logo`, `title`, `content`, `link`) VALUES
(1, 1, 'admin/php/logo/sololearn-logo.jpg', 'SQL', 'I learnt and mastered the Structured Query Language (SQL) which is a prerequisite for Web Backend Development most especially when coding with PHP.', 'admin/php/certificates/SQL.jpg'),
(2, 1, 'admin/php/logo/sololearn-logo.jpg', 'JavaScript', 'I learnt the Javascript syntax on how to develop a Dynamic and Interactive Web content. I successfully completed the 10 project offered by Sololearn to earn the certificate.', 'admin/php/certificates/JavaScript.jpg'),
(3, 1, 'admin/php/logo/sololearn-logo.jpg', 'PHP', 'I learnt and mastered the PHP language which is the base of my Web Backend skills. I successfully completed the 10 projects offered by Sololearn to earn the certificate.', 'admin/php/certificates/PHP.jpg'),
(4, 1, 'admin/php/logo/sololearn-logo.jpg', 'Python For Finance', 'I learnt certain python financial libraries which is to help in analyzing and record keeping of financial data in an efficient and effective manner.', 'admin/php/certificates/PythonBeginners.jpg'),
(5, 1, 'admin/php/logo/jobberman-logo.png', 'Soft Skill', 'I learnt certain Soft Skills needed in workspace in this 21st century some of which are; Time management, Emotional Intelligence, etc.', 'admin/php/certificates/Softskill.png'),
(6, 1, 'admin/php/logo/sololearn-logo.jpg', 'HTML', 'I learnt the basis and the overall abilities of the Hypertext Markup Language (HTML). This is my first programming language :).', 'admin/php/certificates/HTML.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_no` text NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `name`, `email`, `phone_no`, `address`) VALUES
(1, 'John Abiodun', 'johnabiodun@gmail.com', '09015206743', 'General, Oshodi-Ijaye Rd, Lagos, Nigeria');

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `org_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `icon` varchar(100) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `org_id` int(11) NOT NULL,
  `start_date` text NOT NULL,
  `end_date` text NOT NULL,
  `skills` text NOT NULL,
  `date_added` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `experience`
--

INSERT INTO `experience` (`id`, `user_id`, `icon`, `title`, `content`, `org_id`, `start_date`, `end_date`, `skills`, `date_added`) VALUES
(1, 1, 'icon-group', 'Punctuality Prefect', 'Far back in SS2, I emerged as the punctuality prefect of the 2016/2017 Senior Prefects at <strong>Kolabod Private School</strong>. My duty was to resume as early as 7:30am to welcome early students and give penalties to late comers which I did throughout my tenure as a Punctuality Prefect.', 2, 'Oct 2016', 'Aug 2017', 'communication skills, time management, and team spirit.', '2022-12-24 09:32:00'),
(2, 1, 'icon-head', 'Senior Prefect (Head Boy)', 'While in Secondary School, I was privileged to be the Head Boy of the 2017/2018 Senior Prefects at <strong>Kolabod Private School</strong>. I was able to inculcate good behaviours and excellence among the pupils with the help of my Head Girl and other Prefects. Interesting and educative socio-academic programmes were held such as; assembly charge, cultural and debating day, inter-house sports, and social clubs (Press club and Jet club).', 2, 'Oct 2017', 'Aug 2018', 'communication skills, public speaking, event planning, critical thinking, team spirit, and time management.', '2022-12-24 09:32:11'),
(3, 1, 'icon-android', 'Student Intern', 'I did my SIWES at <strong>Artificial Intelligence and Robotics Lab (AIROL), Unilag</strong>, where I learnt about working with teams, thinking about problems faced in our immediate environment, and providing a sustainable solution using the art of Robotics. By the end of the internship, I and my colleagues built two projects - remote control socket and a sensor bulb, using an Arduino Uno Micro-controller.', 4, 'Jan 2022', 'May 2022', 'communication skills, problem solving, critical thinking, team spirit, and Arduino C programming.', '2022-12-24 09:32:22'),
(4, 1, 'icon-head', 'Campus Fellowship Coordinator', 'Being a member of the Apostolic Faith Campus Fellowship at FCE(T) Akoka, was an awesome experience which helped me through school and emerging as a leader with a team of 2 Sisters & a brother, in conjunction with the National President was a beautiful experience. We held 2 National programmes (Themed: Driven & Freed) and wonderful fellowships.', 1, 'Dec 2021', 'Sept 2022', 'leadership skills, public speaking, emotional intelligence, communication skills, time management, team management, and event planning.', '2022-12-24 09:32:33'),
(5, 1, 'icon-pen', 'Teaching Practice', 'As a prospective teacher of a Federal College of Education, I partake in one of the important exercises to be a certified teacher which is Teaching Practice (TP). I did mine at Greendome High School, Iyana-Oworo, Lagos. At the end of the exercise, I emerged as the Best TP student.', 6, 'Jan 2022', 'April 2022', 'Classroom management, team spirit, communication skills, public speaking, emotional intelligence, curriculum planning & development, and time management', '2023-01-02 18:24:30'),
(6, 1, 'icon-laptop', 'Web and Fashion Designer', 'I am a current web developer and also a fashion designer at Sannex Designs. This is my developing business which is aimed at selling bags online. WATCH OUT on my blog for update.', 5, 'Nov 2019', 'Till date', 'digital marketing, content creating, web programming languages, communication skills, pattern designing, bag making.', '2023-01-02 18:24:38');

-- --------------------------------------------------------

--
-- Table structure for table `organisation`
--

CREATE TABLE `organisation` (
  `org_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `org_name` text NOT NULL,
  `org_city` text NOT NULL,
  `org_state` text NOT NULL,
  `org_country` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `organisation`
--

INSERT INTO `organisation` (`org_id`, `user_id`, `org_name`, `org_city`, `org_state`, `org_country`) VALUES
(1, 1, 'Federal College of Education (Technical)', 'Akoka', 'Lagos', 'Nigeria'),
(2, 1, 'Kolabod Private School', 'Ijoko-Lemode', 'Ogun State', 'Nigeria'),
(3, 1, 'Masters Computer College', 'Olaogun', 'Ogun State', 'Nigeria'),
(4, 1, 'Artificial Intelligence and Robotics Lab, Unilag', 'Akoka', 'Lagos', 'Nigeria'),
(5, 1, 'Sannex Designs', 'Ijoko-Lemode', 'Ogun State', 'Nigeria'),
(6, 1, 'Greendome High School', 'Iyana Oworo', 'Lagos', 'Nigeria');

-- --------------------------------------------------------

--
-- Table structure for table `partner`
--

CREATE TABLE `partner` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `portfolio_link` text NOT NULL,
  `phone_no` text NOT NULL,
  `address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `partner`
--

INSERT INTO `partner` (`id`, `name`, `email`, `portfolio_link`, `phone_no`, `address`) VALUES
(1, 'John Abiodun', 'johnabiodun@gmail.com', 'johnportfolio.com', '09015206743', 'General, Oshodi-Ijaye Rd, Lagos, Nigeria');

-- --------------------------------------------------------

--
-- Table structure for table `skill`
--

CREATE TABLE `skill` (
  `user_id` int(11) NOT NULL,
  `rank` int(10) NOT NULL,
  `title` text NOT NULL,
  `level` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `name`, `email`, `password`) VALUES
(1, 'Akinyemi Samuel', 'akinyemisamuel170@gmail.com', 'c612ad79a816708bbe2c18c7722ce64d');

-- --------------------------------------------------------

--
-- Table structure for table `work`
--

CREATE TABLE `work` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category` text NOT NULL,
  `link` varchar(100) NOT NULL,
  `type` enum('cups_of_coffee','project','freelance') NOT NULL,
  `views` int(100) NOT NULL,
  `likes` int(100) NOT NULL,
  `client` text NOT NULL,
  `partner` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `award`
--
ALTER TABLE `award`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `certificate`
--
ALTER TABLE `certificate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `education`
--
ALTER TABLE `education`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experience`
--
ALTER TABLE `experience`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `organisation`
--
ALTER TABLE `organisation`
  ADD PRIMARY KEY (`org_id`);

--
-- Indexes for table `partner`
--
ALTER TABLE `partner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `work`
--
ALTER TABLE `work`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `award`
--
ALTER TABLE `award`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `certificate`
--
ALTER TABLE `certificate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `education`
--
ALTER TABLE `education`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `experience`
--
ALTER TABLE `experience`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `organisation`
--
ALTER TABLE `organisation`
  MODIFY `org_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `partner`
--
ALTER TABLE `partner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `work`
--
ALTER TABLE `work`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
